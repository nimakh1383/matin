package com.example.myapplication23;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class student extends AppCompatActivity {
    // Declare variables
    private EditText nameEditText;
    private EditText ageEditText;
    private EditText gradeEditText;
    private Button saveButton;

    private FirebaseDatabase database;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student);

        // Initialize views
        nameEditText = findViewById(R.id.editTextName);
        ageEditText = findViewById(R.id.editTextAge);
        gradeEditText = findViewById(R.id.editTextGrade);
        saveButton = findViewById(R.id.buttonSave);

        // Initialize Firebase Realtime Database
        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("students");

        // Save button click listener
        saveButton.setOnClickListener(v -> {
            // Get input values
            String name = nameEditText.getText().toString();
            int age = Integer.parseInt(ageEditText.getText().toString());
            double grade = Double.parseDouble(gradeEditText.getText().toString());

            classe newStudent = new classe(name, age, grade);


            addStudentToDatabase(newStudent);

            Intent intent = new Intent();
            intent.putExtra("student", newStudent);
            setResult(RESULT_OK, intent);
            finish();
        });
    }


    private void addStudentToDatabase(classe student) {

        String newStudentKey = databaseReference.child("students").push().getKey();

        databaseReference.child(newStudentKey).setValue(student)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Student added to database", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error adding student to database: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}