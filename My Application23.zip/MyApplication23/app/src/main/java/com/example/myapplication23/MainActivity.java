package com.example.myapplication23;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.Nullable;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView studentListView;
    private Button addStudentButton;
    private TextView selectedStudentNameTextView;
    private TextView selectedStudentAgeTextView;
    private TextView selectedStudentGradeTextView;

    private List<classe> students = new ArrayList<>();
    private ArrayAdapter<classe> studentAdapter;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show);
        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("students");

        studentListView = findViewById(R.id.student_list_view);
        addStudentButton = findViewById(R.id.add_student_button);
        selectedStudentNameTextView = findViewById(R.id.selected_student_name);
        selectedStudentAgeTextView = findViewById(R.id.selected_student_age);
        selectedStudentGradeTextView = findViewById(R.id.selected_student_grade);

        studentAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, students);
        studentListView.setAdapter(studentAdapter);

        studentListView.setOnItemClickListener((parent, view, position, id) -> {
            classe selectedStudent = students.get(position);
            selectedStudentNameTextView.setText("Name: " + selectedStudent.getName());
            selectedStudentAgeTextView.setText("Age: " + selectedStudent.getAge());
            selectedStudentGradeTextView.setText("Grade: " + selectedStudent.getGrade());
        });

        addStudentButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, student.class);
            startActivityForResult(intent, 1);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            classe newStudent = (classe) data.getSerializableExtra("student");
            addStudent(newStudent);
        }
    }

    public void addStudent(classe student) {
        students.add(student);
        studentAdapter.notifyDataSetChanged();
    }
}