package com.example.myapplication23;


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class signup extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);


        FirebaseApp.initializeApp(this, new FirebaseOptions.Builder()
                .setApiKey("AIzaSyCdWTZm-zvpbdGXtnnobPmyY6K5zzgM5M8")
                .build());
        mAuth = FirebaseAuth.getInstance();

        Button signUpButton = findViewById(R.id.sign_up_button);
        signUpButton.setOnClickListener(v -> signUp());
    }

    private void signUp() {
        // 3. Retrieve the email and password from the UI
        EditText emailEditText = findViewById(R.id.email_edit_text);
        EditText passwordEditText = findViewById(R.id.password_edit_text);

        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // 4. Create the user account
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // 5. Retrieve and display the user information
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            String userId = user.getUid();
                            String displayName = user.getDisplayName();
                            String userEmail = user.getEmail();

                            TextView userIdTextView = findViewById(R.id.user_id_text_view);
                            TextView displayNameTextView = findViewById(R.id.display_name_text_view);
                            TextView emailTextView = findViewById(R.id.email_text_view);

                            userIdTextView.setText(userId);
                            displayNameTextView.setText(displayName);
                            emailTextView.setText(userEmail);
                        }
                    } else {
                        // 6. Handle sign-up error
                        Toast.makeText(signup.this, "Sign-up failed.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }
}